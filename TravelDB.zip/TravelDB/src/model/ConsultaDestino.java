/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;


/**
 *
 * @author matia
 */
public class ConsultaDestino extends ConexionDB {
    
     public static int agregar(Destino des){
        Connection conn = getConexion();
        int resultado = 0;
        String query = "INSERT INTO `destino` (`nombre`, `ubicacion`, `precio`, `categoria`) VALUES (?, ?, ?, ?)";
        
         try {
        PreparedStatement st = (PreparedStatement) conn.prepareStatement(query);
        st.setString(1, des.getNombre());
        st.setString(2, des.getUbicacion());
        st.setInt(3, des.getPrecio());
        st.setString(4, des.getCategoria());

        resultado = st.executeUpdate();
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        }finally {
        try {
            conn.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
         
         
        return resultado;
     }
     
     public static int modificar(Destino des){
        Connection conn = getConexion();
        int resultado = 0;
        String query = "UPDATE `destino` SET `nombre`=?, `ubicacion`=?, `precio`=?, `categoria`=? WHERE `id`=?";
    
        try {
        PreparedStatement st = (PreparedStatement) conn.prepareStatement(query);
        st.setString(1, des.getNombre());
        st.setString(2, des.getUbicacion());
        st.setInt(3, des.getPrecio());
        st.setString(4, des.getCategoria());
        st.setString(5, des.getId()); // Agrega el ID en el WHERE

        resultado = st.executeUpdate();
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        }finally {
        try {
            conn.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        
     }
        
        return resultado;
    }
     
     public static int borrar(String id){
        Connection conn = getConexion();
        int resultado = 0;
        String query = "DELETE FROM `destino` WHERE `id`='"+id+"'";
       
        try {
        Statement st = conn.createStatement();
        resultado = st.executeUpdate(query);

    } catch (SQLException ex) {
        System.out.println(ex.getMessage());
    } finally {
        try {
            conn.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    
    }
    
        return resultado;
        }
   
     
     public static ArrayList<Destino> leer(){
        ArrayList<Destino> destinos = new ArrayList<>();
        Connection conn = getConexion();
        ResultSet resultado = null;
        
        String query = "SELECT `id`, `nombre`, `ubicacion`, `precio`, `categoria` FROM `destino`";
        try{
            Statement st = conn.createStatement();
            resultado = st.executeQuery(query);
            while(resultado.next()){
                Destino d = new Destino(
                        resultado.getString("id"),
                        resultado.getString("nombre"),
                        resultado.getString("ubicacion"),
                        resultado.getString("categoria"),
                        resultado.getInt("precio")
                        );
                    destinos.add(d);
          }
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        
        }
        
        return destinos;
     }
     

      public static ArrayList<Destino> leerConDatos(String id){
        ArrayList<Destino> destinos = new ArrayList<>();
        Connection conn = getConexion();
        ResultSet resultado = null;
        String query = "SELECT `id`, `nombre`, `ubicacion`, `precio`, `categoria` FROM `destino` WHERE `id` ='"+id+"'";
        try{
            Statement st = conn.createStatement();
            resultado = st.executeQuery(query);
            while(resultado.next()){
                Destino d = new Destino(
                    resultado.getString("id"), 
                    resultado.getString("nombre"), 
                    resultado.getString("ubicacion"),
                    resultado.getString("categoria"),
                     resultado.getInt("precio")
                    
                       
                   
                );
                destinos.add(d);
            }
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        }
        return destinos;

      }
      public static boolean isIdExists(String id) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
 try {
           
            String query = "SELECT * FROM `destino` WHERE id = '"+id+"'";
            Connection conn = getConexion();
            statement = (PreparedStatement) connection.prepareStatement(query);
            statement.setString(1, id);
            resultSet = statement.executeQuery();
            
            return resultSet.next();
            } catch (SQLException e) {
                e.printStackTrace();
                return false;
                } finally {
     try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace(); // Manejo adecuado de la excepción en una aplicación real
            }
        }
 }

  
}
       

