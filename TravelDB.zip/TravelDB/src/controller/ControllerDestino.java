/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;


import java.util.ArrayList;
import model.ConsultaDestino;
import model.Destino;


/**
 *
 * @author matia
 */
public class ControllerDestino {
    
     public static int crtlAgregar(Destino des){
        int resultado = 0;
        try{
            resultado = ConsultaDestino.agregar(des);
            
            if (resultado==1){
                System.out.println("Se agregó correctamente");
            }else{
                System.out.println("Hubo un problema");
            }
        } catch (Exception ex){
            System.out.println(ex.getMessage());
        }
        return resultado;
     } 
     
     public static void crtlModificar(Destino des){
        try{
            int resultado = ConsultaDestino.modificar(des);
            
            if (resultado==1){
                System.out.println("Se modificó correctamente");
            }else{
                System.out.println("No se realizó ninguna modificación. Verifica que el destino exista y los datos sean válidos.");
            }
            
        } catch (Exception ex){
            System.out.println("Hubo un problema al intentar modificar el destino: " + ex.getMessage());
    
        }
        
    } 
     
     public static ArrayList<Destino> crtlLeer(){
        ArrayList<Destino> resultado = null;
        try{
            resultado = ConsultaDestino.leer();
        } catch (Exception ex){
            System.out.println(ex.getMessage());
        }
        
        return resultado;
    }

    public static ArrayList<Destino> crtlBuscar(String text) {
        ArrayList<Destino> resultado = new ArrayList<>();
        try{
            ArrayList<Destino> destinosEncontrados = ConsultaDestino.leerConDatos(text);
            if (destinosEncontrados != null) {
                resultado.addAll(destinosEncontrados);
                } else {
                System.out.println("No se encontraron destinos con el Id selecionada.");
                }     
            
        } catch (Exception ex){
            System.out.println(ex.getMessage());
        }
        
        return resultado;
    
    }
     
    public static void crtlBorrar(String text){
        try{
            int resultado = ConsultaDestino.borrar(text);
            
            if (resultado==1){
                System.out.println("Se ha eliminado correctamente");
            }else{
                System.out.println("Hubo un error al intentar eliminar el registro.");
            }
        } catch (Exception ex){
            System.out.println("Error al intentar eliminar el registro: " + ex.getMessage());
        }
   
        
    }
    public static boolean isIdExists(String text) {
        ArrayList<Destino> destinos = crtlBuscar(text);
        return destinos != null && !destinos.isEmpty();
    }

    
}